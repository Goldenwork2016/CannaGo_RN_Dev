module.exports = {
  
    project: {
        ios: {},
        android: {}, // grouped into "project"
      },
    assets: ["./src/assets/fonts"]
  
};