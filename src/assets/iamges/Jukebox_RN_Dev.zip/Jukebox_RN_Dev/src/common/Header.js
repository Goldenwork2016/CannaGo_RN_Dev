import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Text from './Text';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { normalizeFont, normalizeX, normalizeY } from '../utils/Utils';
import { poppins_Medium, WHITE_COLOR } from '../utils/constants';

export default  Header  = (props) => {
    const { headerTitle, onPress } = props
    return (
      <>
        <View style={[styles.headerContainer]}>
          <TouchableOpacity style={styles.backArrow} onPress={onPress}>
            <Ionicons
              color="#000"
              name="chevron-back"
              size={normalizeFont(24, true)}
            />
          </TouchableOpacity>
          <View style={{alignItems:"center"}}>  
          <Text bolder style={[styles.headerText,]}>{headerTitle}</Text>
          </View>
        </View>
      </>
    );
}

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    height: normalizeY(55),
    alignItems: 'center',
    backgroundColor: WHITE_COLOR
  },
  backArrow: {
    width: normalizeY(35),
    height: normalizeY(35),
    borderRadius: 10,
    marginLeft: normalizeX(15),
    flexDirection:"row",
    alignItems: "center",
    justifyContent: 'flex-start',
    flex:0.42
  },
  headerText: {
    marginLeft: normalizeX(12),
    fontSize: normalizeFont(12),
    fontFamily: poppins_Medium,
    flexDirection:"row"
    // backgroundColor: 'red'
  }
})
