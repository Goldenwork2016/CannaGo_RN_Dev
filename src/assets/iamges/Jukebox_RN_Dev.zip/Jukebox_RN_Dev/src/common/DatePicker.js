import React, { PureComponent } from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { normalizeFont, normalizeX, normalizeY } from "../../utils/Utils";
import Text from './Text';
import theme from '../../utils/theme'
import Moment from 'moment';
import { mulish_regular } from '../../utils/Constants';


export default class DatePicker extends PureComponent {

  state = {
    isDatePickerVisible: false,
    date: new Date()


  }

  handleDateChange = (date) => {

    this.setState({date : date})
    this.hideDatePicker()
  }

  hideDatePicker = () => {
    this.setState({ isDatePickerVisible: false });
  }

  showDatePicker = () => {
    this.setState({ isDatePickerVisible: true });
  }

  render() {
    const {date} = this.state;
   const formateDate = Moment(date).format('YYYY-MM-DD')
    const { style, placeholder, selectedDate, iconColor, iconSize, onChange, theme } = this.props;
    const { isDatePickerVisible } = this.state;
    onChange(formateDate)
    return (
      <View style={{ ...styles.container, ...style }}>
        <Text style={[styles.placeholderText, {color: theme.colors.TEXTINPUT_LABEL_COLOR}]}>{placeholder}</Text>
        <TouchableOpacity onPress={this.showDatePicker} style={styles.iconInputContainer}>
          <MaterialIcons
            name={'date-range'}
            color={theme.colors.LABEL_COLOR}
            size={iconSize || normalizeFont(16, true)}
            style={styles.icon}
          />
          <Text style={[styles.text, {color: theme.colors.LABEL_COLOR }]}>{date.toLocaleDateString()}</Text>
        </TouchableOpacity>
        <DateTimePickerModal
          pickerContainerStyleIOS={{ color: theme.colors.LABEL_COLOR }}
          isVisible={isDatePickerVisible}
          mode="date"
          color={theme.colors.LABEL_COLOR}
          style={{color: theme.colors.LABEL_COLOR}}
          date={this.state.date}
          onConfirm={this.handleDateChange}
          onCancel={this.hideDatePicker}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'grey',
  },
  placeholderText: {
    fontSize: 12,
    color: theme.TEXTINPUT_LABEL_COLOR,
  },
  iconInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: normalizeY(40) > 50 ? 50 : normalizeY(40),
    // backgroundColor: 'red',
  },
  icon: {
    marginRight: 5,
  },
  text: {
    fontSize: normalizeFont(12.5),
    fontFamily: mulish_regular,
    color: theme.LABEL_COLOR
  },
})