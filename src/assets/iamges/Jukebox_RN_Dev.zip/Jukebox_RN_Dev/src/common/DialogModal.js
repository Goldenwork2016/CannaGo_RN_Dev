import React, { useState, useRef } from 'react';
import {
    StyleSheet,
    View,
    Modal,
} from "react-native";

import LinearGradient from 'react-native-linear-gradient';
import { mulish_bold } from '../../utils/Constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import Button from './Button';
import Text from './Text';
import { useTheme } from '@react-navigation/native';




export default DialogModal = (props) => {


    const myTheme = useTheme();
    const [isVisible, setVisible] = useState(true)


    const getButtons = () => {
        if (props.modalType === 'info') {
            return (
                <View style={styles.buttonsContainer}>
                    <Button style={{ width: '30%' }} title={props.buttons[0]} onPress={() =>  props.positiveButtonPressed()} />
                </View>
            )

        }
        else if (props.modalType === 'interactive') {
            return (

                <View style={styles.buttonsContainer}>

                    <Button style={{ width: '30%' }} title={props.buttons[0]} onPress={() => {props.positiveButtonPressed() , setVisible(false)} } />
                    <Button style={{ width: '30%' }} title={props.buttons[1]} onPress={() => {props.negativeButtonPressed(), setVisible(false)}} />
                </View>
            )
        }
    }

    return (
        <View  >

            <Modal
                animationType="slide"
                transparent={true}
                visible={isVisible}
                onRequestClose={() => {

                }}>
                <View style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignContent: 'center',
                    backgroundColor: '#000000',
                    opacity: 0.9,
                }}>

                    <LinearGradient colors={[myTheme.colors.DARK_GRADIENT_FIRST_COLOR, myTheme.colors.DARK_GRADIENT_SECOND_COLOR]} style={styles.centeredView}>

                        <Text style={[styles.textStyle, { color: myTheme.colors.LABEL_COLOR }]}>{props.message}</Text>

                        {getButtons()}

                    </LinearGradient>

                </View>

            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({

    centeredView: {
        flexDirection: "column",
        borderRadius: 10,
        paddingVertical: normalizeY(20),
        marginHorizontal: normalizeX(20)
    },

    textStyle: {
        textAlign: "center",
        fontFamily: mulish_bold,
        marginTop: normalizeY(10),
        fontSize: normalizeFont(15),
    },

    buttonsContainer: {
        justifyContent: 'space-around',
        marginTop: normalizeY(20),
        flexDirection: 'row',
    },

});

