
import { Dimensions, Platform } from 'react-native';

const { width, height } = Dimensions.get('window')

export const SCREEN_WIDTH = width;
export const isIOS = Platform.OS === 'ios' ? true : false;
export const isAndroid = Platform.OS === 'android' ? true : false;
export const SCREEN_HEIGHT = height;
export const ASPECT_RATIO = SCREEN_HEIGHT / SCREEN_WIDTH;
export const BASE_UNIT_WIDTH = 320;
export const BASE_UNIT_HEIGHT = 640;
export const BASE_ASPECT_RATIO = BASE_UNIT_HEIGHT / BASE_UNIT_WIDTH;
export const ASPECT_DIFF = ASPECT_RATIO / BASE_ASPECT_RATIO;

// colors
export const TEXT = 'black'
export const WHITE_COLOR = "#FFFFFF"
export const GREY_COLOR  ='#9C9C9C'
export const BLACK_COLOR = '#212121'
export const Dodger_Blue ='#0091ff'
export const Line_Color ='#E5E5E5'


// font family

export const poppins_Bold = "Poppins-Bold"
export const poppins_Medium = "Poppins-Medium"
export const poppins_Regular = "Poppins-Regular"