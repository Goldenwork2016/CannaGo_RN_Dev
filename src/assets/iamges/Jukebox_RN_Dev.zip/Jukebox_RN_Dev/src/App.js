import 'react-native-gesture-handler';

import * as React from 'react';
import Navigator from "./navigators/AppNavigation";
function App() {
  return (
    <Navigator />
  )
}

export default App;