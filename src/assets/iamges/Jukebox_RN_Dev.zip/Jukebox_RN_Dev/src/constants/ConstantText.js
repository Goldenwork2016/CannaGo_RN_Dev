export default {
    support: 'Send this link to your friends and receive free deliveries:Send this link to your friends and receive free deliveries:Send this link to your friends and receive free deliveries:Send this link to your friends and receive free deliveries:',
}
