export default {
    main: '#79B1AD',
    progress: '#5D9D9B',
    secondary: '#E98D6A',
    bgSecondary: '#F2A786',
    bottomBar: '#0091FF',
    disable: '#959595',
    white: '#FFFFFF',
    shoot: '#FF6464'
}
