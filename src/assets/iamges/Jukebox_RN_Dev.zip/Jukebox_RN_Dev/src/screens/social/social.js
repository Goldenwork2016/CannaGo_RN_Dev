//import liraries
import React, { useState, useRef } from 'react';
import { View, StyleSheet, FlatList, SafeAreaView, TouchableOpacity, Image, Dimensions, TextInput } from 'react-native';
import MenuIcon from '../../components/MenuIcon'
import TextComponent from '../../components/TextComponent'
import SettingItem from '../../components/SettingItem'
import Modal from 'react-native-modalbox';
import { useNavigation } from 'react-navigation-hooks'

const settings = require('../../assets/images/Settings.png')
const bluetooth = require('../../assets/images/Bluetooth.png')
const { width, height } = Dimensions.get('window')
const youtube = require('../../assets/images/youtube.png')
const tidal = require('../../assets/images/tidal.png')
const instagram = require('../../assets/images/instagram.png')
const facebook = require('../../assets/images/facebook.png')
const yellow = require('../../assets/images/yellow.png')
const twitter = require('../../assets/images/twitter.png')
const tiktok = require('../../assets/images/tiktok.png')
const linkedin = require('../../assets/images/linkedin.png')


const Social = () => {
  const [musicContent, setMusicContent] = useState([
    { id: 1, url: instagram },
    { id: 2, url: facebook },
    { id: 3, url: yellow },
    { id: 4, url: twitter },
    { id: 5, url: tiktok },
    { id: 6, url: linkedin },
    { id: 7, url: youtube },
    { id: 8, url: tidal },
  ])
  const [search, setSearch] = useState('')
  const modalRef = useRef('modal1')
  const { navigate } = useNavigation()
  function openDrawer() {
    modalRef.current.open()
  }
  const renderMusicContent = ({ item }) => (
    <TouchableOpacity style={styles.musicItemArea} onPress={() => console.log(item.id)} activeOpacity={0.5} >
      <Image source={item.url} style={styles.musicItem} resizeMode="contain" />
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <MenuIcon onPress={() => openDrawer()} />
      <TextComponent stitle PopBold>    Social Media{'\n'}    Apps</TextComponent>
      <View style={{ width: '100%', alignItems: 'center', height: height -250}}>
        <TextInput
          value={search}
          onChangeText={(val)=>setSearch(val)}
          style={styles.srchInput}
          placeholder="Search"
        />
        <FlatList
          data={musicContent}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderMusicContent}
          numColumns={2}
        />
      </View>
      <Modal style={styles.modal} position={"bottom"} ref={modalRef} swipeArea={20}>
        <View style={styles.bar}></View>
        <SettingItem src={settings} title="Settings" onPress={() => navigate('Settings')} />
        <SettingItem src={bluetooth} title="Bluetooth / Device Linking" onPress={() => navigate('Bluetooth')} />
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    width: '100%',
  },
  avatarArea: {
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    margin: 20
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: 35,
    margin: 10
  },
  profileContentItem: {
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
    paddingVertical: 10,
    paddingHorizontal: 20
  },
  modal: {
    width: '100%',
    height: 230,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  bar: {
    alignSelf: 'center',
    width: 60,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'grey',
    marginBottom: 20
  },
  musicItem: {
    width: width * 0.46,
    height: width * 0.35
  },
  srchInput: {
    width: '92%',
    height: 50,
    paddingLeft: 20,
    borderRadius: 25,
    borderColor: '#E5E5E5',
    borderWidth: 1,
    fontFamily: 'Poppins-Regular',
    fontSize: 15,
    paddingBottom: 5,
    marginBottom: 25
  },
  musicItemArea: { 
    marginHorizontal: width * 0.01,
    marginVertical: width * 0.01
  }
});


export default Social
