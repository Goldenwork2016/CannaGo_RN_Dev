//import liraries
import React, { useState, useRef, useEffect } from 'react';
import { View, StyleSheet, FlatList, SafeAreaView, TouchableOpacity, Image, Platform } from 'react-native';
import MenuIcon from '../../components/MenuIcon'
import TextComponent from '../../components/TextComponent'
import SettingItem from '../../components/SettingItem'
import Modal from 'react-native-modalbox';
import { useNavigation } from 'react-navigation-hooks'

const avatar = require('../../assets/images/profile2.png')
const settings = require('../../assets/images/Settings.png')
const bluetooth = require('../../assets/images/Bluetooth.png')

const Home = () => {
  const [profileContent, setProfileContent] = useState([
    { id: 1, title: 'Payment', sub: 'Visa **34', nav: 'Payment' },
    { id: 2, title: 'Address', sub: 'Address', nav: 'AccountAddress' },
    { id: 3, title: 'Support', sub: 'Support', nav: 'Support' },
    { id: 4, title: 'Promo Codes', sub: 'Promo Codes', nav: 'PromoCode' },
  ])
  const modalRef = useRef('modal1')
  const { navigate } = useNavigation()
  useEffect(() => {
    let isMounted = true; // note this flag denote mount status
    if (isMounted) console.log('HomeIsMounted');
    return () => { isMounted = false }; // use effect cleanup to set flag false, if unmounted
  }, []);
  function openDrawer() {
    modalRef.current.open()
  }
  const renderProfileContent = ({ item }) => (
    <TouchableOpacity style={styles.profileContentItem} onPress={() => navigate(item.nav)}>
      <TextComponent xmedium PopMedium>{item.title}</TextComponent>
      <TextComponent lightgrey>{item.sub}</TextComponent>
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <MenuIcon onPress={() => openDrawer()} />
      <TextComponent stitle PopBold>    Profile</TextComponent>
      <View style={styles.avatarArea}>
        <TouchableOpacity onPress={() => navigate('Profile')} activeOpacity={0.5} >
          <Image source={avatar} style={styles.avatar} />
        </TouchableOpacity>
        <View>
          <TextComponent xmedium PopMedium>Jeep Worker</TextComponent>
          <TextComponent lightgrey>email@email.com</TextComponent>
        </View>
      </View>
      <FlatList
        data={profileContent}
        keyExtractor={(item, index) => index.toString()}
        renderItem={renderProfileContent}
      />
      <Modal style={styles.modal} position={"bottom"} ref={modalRef} swipeArea={20}>
        <View style={styles.bar}></View>
        <SettingItem src={settings} title="Settings" onPress={() => navigate('Settings')} />
        <SettingItem src={bluetooth} title="Bluetooth / Device Linking" onPress={() => navigate('Bluetooth')} />
      </Modal>
    </SafeAreaView>
  );
};

export default Home

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  avatarArea: {
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    margin: 20
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: 35,
    margin: 10
  },
  profileContentItem: {
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
    paddingVertical: 10,
    paddingHorizontal: 20
  },
  modal: {
    width: '100%',
    height: 230,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  bar: {
    alignSelf: 'center',
    width: 60,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'grey',
    marginBottom: 20
  }
});



