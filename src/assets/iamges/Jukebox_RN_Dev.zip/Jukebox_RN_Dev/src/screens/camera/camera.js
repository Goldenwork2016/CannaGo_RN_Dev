'use strict';
import React, { PureComponent } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View, Dimensions } from 'react-native';
import { RNCamera } from 'react-native-camera';
import Shoot from '../../components/Shoot'
import TextComponent from '../../components/TextComponent'
import Colors from '../../constants/Colors'
import ProgressBar from 'react-native-progress/Bar';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const { width, height } = Dimensions.get('window')
const rect = require('../../assets/images/rect.png')
const playBar = require('../../assets/images/playBar.png')

const PendingView = () => (
  <View
    style={{
      flex: 1,
      backgroundColor: 'lightgreen',
      justifyContent: 'center',
      alignItems: 'center',
      width: '100%',
      height: '100%'
    }}
  >
    <Text>Waiting</Text>
  </View>
);

class Camera extends PureComponent {
  takePicture = async function (camera) {
    const options = { quality: 0.5, base64: true };
    const data = await camera.takePictureAsync(options);
    //  eslint-disable-next-line
    console.log(data.uri);
  };
  render() {


    return (
      <View style={styles.container}>
        <RNCamera
          style={styles.preview}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.on}
          androidCameraPermissionOptions={{
            title: 'Permission to use camera',
            message: 'We need your permission to use your camera',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
          androidRecordAudioPermissionOptions={{
            title: 'Permission to use audio recording',
            message: 'We need your permission to use your audio',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
        >
          {({ camera, status, recordAudioPermissionStatus }) => {
            if (status !== 'READY') return <PendingView />;
            return (
              <View style={styles.subContainer}>
                <View style={styles.playing}>
                  <ProgressBar
                    style={styles.progressBar}
                    progress={0.3}
                    width={width * 0.96}
                    useNativeDriver={false}
                    color={Colors.shoot}
                  />
                  <View style={styles.songArea}>
                    <View style={styles.song}>
                      <TextComponent white PopBold medium>Name Song 1</TextComponent>
                      <TextComponent white small>Singer</TextComponent>
                      <Image source={playBar} style={styles.playBar} resizeMode="contain" />
                    </View>
                    <MaterialCommunityIcons name="close" size={30} color="white" style={styles.close} />
                  </View>
                </View>
                <View style={{ width: '100%' }}>
                  <View style={styles.whiteBox}>
                    <MaterialCommunityIcons name="close" size={30} color="black" style={styles.close} />
                  </View>
                  <TouchableOpacity style={styles.bitmoji} onPress={() => console.log('Bitmoji')}>
                    <TextComponent white PopMedium>Create a Bitmoji</TextComponent>
                  </TouchableOpacity>
                  <View style={styles.ShootArea}>
                    <View style={styles.rectArea}>
                      <TouchableOpacity onPress={() => console.log('Effects')}>
                        <Image source={rect} style={styles.rect} />
                      </TouchableOpacity>
                      <TextComponent white small PopBold>Effects</TextComponent>
                    </View>
                    <Shoot onPress={() => this.takePicture(camera)} />
                    <View style={styles.rectArea}>
                      <TouchableOpacity onPress={() => console.log('Upload')}>
                        <Image source={rect} style={styles.rect} />
                      </TouchableOpacity>
                      <TextComponent white small PopBold>Upload</TextComponent>
                    </View>
                  </View>
                </View>
              </View>
            );
          }}
        </RNCamera>
      </View>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'black',
  },
  subContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-between'
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  capture: {
    flex: 0,
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
  ShootArea: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '86%',
    alignItems: 'center',
    marginLeft: '7%',
    marginBottom: 60
  },
  rect: {
    width: 32,
    height: 32,
    borderRadius: 3,
    borderWidth: 2,
    borderColor: 'white'
  },
  rectArea: {
    alignItems: 'center',
  },
  bitmoji: {
    justifyContent: 'center',
    alignItems: "center",
    borderRadius: 17,
    width: 140,
    height: 34,
    backgroundColor: Colors.bottomBar,
    alignSelf: 'center',
    marginBottom: 35
  },
  progressBar: {
    backgroundColor: '#FFF4',
    borderWidth: 0,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 30
  },
  songArea: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  song: {
    alignItems: 'center',
    backgroundColor: '#FFF2',
    paddingHorizontal: 40,
    paddingVertical: 8,
    borderRadius: 15
  },
  close: {
    position: 'absolute',
    right: 10,
    top: 10
  },
  playing: {
    flexDirection: 'column',
  },
  playBar: {
    width: 160,
    height: 23
  },
  whiteBox: {
    width: 135,
    height: 165,
    borderRadius: 20,
    backgroundColor: '#FFFC',
    alignSelf: 'flex-end',
    margin: 20,
  }
});

export default Camera