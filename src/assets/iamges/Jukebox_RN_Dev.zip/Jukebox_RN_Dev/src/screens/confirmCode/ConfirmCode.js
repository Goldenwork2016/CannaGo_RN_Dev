//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import Text from '../../../src/common/Text'
import { BLACK_COLOR, COLOR_WHITE, Dodger_Blue, GREY_COLOR, poppins_Bold, poppins_Medium, poppins_Regular, WHITE_COLOR } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import TextComponent from '../../components/TextComponent'
import CustomInput from '../../components/CustomInput'
import MainButton from '../../components/MainButton'
import Header from '../../common/Header'
import { useNavigation } from 'react-navigation-hooks'


const ConfirmCode = () => {
    const [code, setCode] = useState('');
    const { navigate } = useNavigation()
    return (
        <View style={styles.container}>
            <Header onPress={() => navigate('Forgot')} />
            <View style={styles.body}>
                <View style={{ marginBottom: 40 }}>
                    <Text style={styles.welcomeText}>{`Confirm Code`}</Text>
                </View>
                <TextComponent H25>Enter the verification code sent to your email address to reset password.</TextComponent>
                <View style={{ marginVertical: 10 }}>
                    <CustomInput label="Enter code" value={code} onChangeText={(val) => setCode(val)} />
                </View>
                <MainButton title="Confirm" onPress={() => navigate('Change')} />
            </View>
        </View>
    );
};

export default ConfirmCode

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1
    },
    welcomeText: {
        fontFamily: poppins_Bold,
        fontSize: normalizeFont(26, true),
        marginTop: normalizeY(10),
        marginLeft: normalizeX(5)
    },
});



