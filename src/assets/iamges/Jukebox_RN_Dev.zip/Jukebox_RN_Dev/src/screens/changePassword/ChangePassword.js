//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import Text from '../../../src/common/Text'
import { BLACK_COLOR, COLOR_WHITE, Dodger_Blue, GREY_COLOR, poppins_Bold, poppins_Medium, poppins_Regular, WHITE_COLOR } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import TextComponent from '../../components/TextComponent'
import CustomInput from '../../components/CustomInput'
import MainButton from '../../components/MainButton'
import Header from '../../common/Header'
import { useNavigation } from 'react-navigation-hooks'


const ChangePassword = () => {
    const [newPwd, setNewPwd] = useState('');
    const [confirmPwd, setConfirmPwd] = useState('');
    const { navigate } = useNavigation()
    return (
        <View style={styles.container}>
            <Header onPress={() => navigate('Confirm')} />
            <View style={styles.body}>
                <Text style={styles.welcomeText}>{`Change Password`}</Text>
                <TextComponent H25>Enter your new password and confirm.</TextComponent>
                <View style={{ marginVertical: 10 }}>
                    <CustomInput label="New Password" value={newPwd} onChangeText={(val) => setNewPwd(val)} />
                    <CustomInput label="Confirm Password" value={confirmPwd} onChangeText={(val) => setConfirmPwd(val)} />
                </View>
                <MainButton title="Return to login" onPress={() => navigate('Login')} />
            </View>
        </View>
    );
};

export default ChangePassword

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1
    },
    welcomeText: {
        fontFamily: poppins_Bold,
        fontSize: normalizeFont(26, true),
        marginTop: normalizeY(10),
        marginLeft: normalizeX(5),
        marginBottom: 40
    },
});



