//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { normalizeX, normalizeY } from '../../utils/Utils';
import Header from '../../common/Header'
import MainButton from '../../components/MainButton';
import CustomInput from '../../components/CustomInput';
import { useNavigation } from 'react-navigation-hooks'

const Address = () => {
    const [address, setAddress] = useState('');
    const [address1, setAddress1] = useState('');
    const [city, setCity] = useState('');
    const [state, setState] = useState('');
    const [zip, setZip] = useState('');
    const { navigate } = useNavigation()
    return (
        <View style={styles.container}>
            <Header headerTitle="ADDRESS" onPress={() => navigate('AccountAddress')} />
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.body}>
                    <CustomInput label="Address" value={address} onChangeText={(val) => setAddress(val)} />
                    <CustomInput label="Address1" value={address1} onChangeText={(val) => setAddress1(val)} />
                    <CustomInput label="City" value={city} onChangeText={(val) => setCity(val)} />
                    <CustomInput label="State" value={state} onChangeText={(val) => setState(val)} />
                    <CustomInput label="Zip" value={zip} onChangeText={(val) => setZip(val)} />
                    <View style={styles.space}></View>
                    <MainButton title="Continue" onPress={() => navigate('Support')} />
                </View>
            </ScrollView>
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        marginTop: normalizeY(20),
        flex: 1,
        marginBottom: normalizeY(10)
    },
    space: {
        width: '100%',
        height: 20
    }
});

export default Address