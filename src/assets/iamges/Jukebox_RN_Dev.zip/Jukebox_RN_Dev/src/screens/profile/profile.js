//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity, Image } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Header from '../../common/Header'
import { Dodger_Blue } from '../../utils/constants';
import { normalizeX, normalizeY } from '../../utils/Utils';
import TextComponent from '../../components/TextComponent'
import CustomInput from '../../components/CustomInput'
import MainButton from '../../components/MainButton'
import { useNavigation } from 'react-navigation-hooks'

const avatar = require('../../assets/images/photo_user.png')

const Profile = () => {
    const [email, setEmail] = useState('');
    const [fullName, setFullName] = useState('');
    const { navigate } = useNavigation()
    function avatarChange() {
        console.log('---------');
    }
    return (
        <SafeAreaView style={styles.container}>
            <Header headerTitle="Profile" onPress={() => navigate('Home')} />
            <View style={styles.body}>
                <View style={styles.avatar}>
                    <Image source={avatar} style={{ height: 104, width: 100 }} />
                    <TouchableOpacity style={styles.plus} activeOpacity={0.7} onPress={() => avatarChange()}>
                        <AntDesign name="plus" color="white" size={15} />
                    </TouchableOpacity>
                </View>
                <TextComponent stitle PopMedium center mb20 mt20>Jeep Worker</TextComponent>
                <View style={{ width: '100%', height: 20 }}></View>
                <CustomInput label="Full Name" value={fullName} onChangeText={(val) => setFullName(val)} />
                <CustomInput label="Email" value={email} onChangeText={(val) => setEmail(val)} />
                <View style={{ width: '100%', height: 20 }}></View>
                <MainButton title="Save" onPress={() => navigate('App')} />
            </View>
        </SafeAreaView>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1,
        marginBottom: normalizeY(10)
    },
    plus: {
        position: 'absolute',
        zIndex: 12,
        right: 0,
        bottom: 10,
        backgroundColor: Dodger_Blue,
        width: 30,
        height: 30,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
    },
    avatar: {
        justifyContent: 'center',
        alignItems: "center",
        backgroundColor: 'white',
        alignSelf: 'center',
    },
});



export default Profile