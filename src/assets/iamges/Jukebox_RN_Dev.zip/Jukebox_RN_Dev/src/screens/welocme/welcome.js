//import liraries
import React, { Component } from 'react';
import { View, StyleSheet, ScrollView, TextInput, TouchableOpacity } from 'react-native';
import Text from '../../../src/common/Text'
import { BLACK_COLOR, COLOR_WHITE, Dodger_Blue, GREY_COLOR, poppins_Bold, poppins_Medium, WHITE_COLOR } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';



export default Welcome = () => {
    return (
        <View style={styles.container}>




<View style={styles.body}>


<Text style={styles.welcomeText}>{`Welcome to
Jukebox Carousel`}</Text>



<View style={styles.inputContainer} >

<Text style={styles.titleStyle}>Email</Text>

<TextInput placeholder="aamir@plaskt.ca" keyboardType="email-address"  placeholderTextColor={BLACK_COLOR}  style={styles.inputStyle} />

</View>

<View style={styles.inputContainer} >

<Text style={styles.titleStyle}>Password</Text>

<TextInput  secureTextEntry={true}  placeholderTextColor={BLACK_COLOR}  style={styles.inputStyle} />

</View>

<View style={{alignItems: "flex-end"}}>

<Text style={{color: Dodger_Blue, fontFamily: poppins_Medium, fontSize: normalizeFont(15), marginTop: normalizeY(10)}}>Forgot your password?</Text>

</View>

        </View>

<TouchableOpacity style={{height: 56, width: 325, backgroundColor: Dodger_Blue, marginHorizontal: normalizeX(16), borderRadius: 50, justifyContent:"center", alignItems:"center"}} >
    <Text style={{color: WHITE_COLOR, fontFamily: poppins_Medium, fontSize: normalizeFont(17) }}>Sign In</Text>
</TouchableOpacity>

<TouchableOpacity style={{height: 35, width: 325, backgroundColor: 'transparent', marginHorizontal: normalizeX(16),marginTop: normalizeY(5) ,borderRadius: 50, justifyContent:"center", alignItems:"center"}} >
    <Text style={{color: Dodger_Blue, fontFamily: poppins_Medium, fontSize: normalizeFont(17) }}>Sign Up</Text>
</TouchableOpacity>


            
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLOR_WHITE,
    },
    body: {
        marginHorizontal: normalizeX(16),
        marginTop: normalizeY(50),
        flex:1
    },
    welcomeText: {
        fontFamily: poppins_Bold,
        fontSize: normalizeFont(26,true),
        marginTop: normalizeY(10),
        marginLeft:normalizeX(5)

    },
    inputContainer: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: "#E6E6E6",
     height: 80, 
     marginLeft: normalizeX(5),
     marginTop: normalizeY(30),
     borderRadius: 6
    },
    titleStyle: {
        color: GREY_COLOR, 
        marginLeft: normalizeX(20),
        marginTop: normalizeY(10) 
    },
    inputStyle: {
        marginLeft: normalizeX(15),
         fontFamily: poppins_Medium, 
         fontSize: normalizeFont(17)
    }
});



