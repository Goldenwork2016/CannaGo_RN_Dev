//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Dimensions, TouchableOpacity, Image, Platform, Alert } from 'react-native';
import Text from '../../../src/common/Text'
import AntDesign from 'react-native-vector-icons/AntDesign';
import CheckBox from '@react-native-community/checkbox';
import { BLACK_COLOR, COLOR_WHITE, Dodger_Blue, GREY_COLOR, Line_Color, poppins_Bold, poppins_Medium, poppins_Regular, WHITE_COLOR } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import Header from '../../common/Header'
import CustomInput from '../../components/CustomInput';
import MainButton from '../../components/MainButton';
import TextComponent from '../../components/TextComponent';
import { useNavigation } from 'react-navigation-hooks'
import Modal from 'react-native-modal';


const { width, height } = Dimensions.get('window')

export default SignUp = () => {
    const avatar = require("../../assets/images/profile2.png")
    const [value, setValue] = useState(false);
    const [username, setUsername] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [cameraAllow, setCameraAllow] = useState(false);
    const [musicAllow, setMusicAllow] = useState(false);
    const [socialAllow, setSocialAllow] = useState(false);
    const [alertNum, setAlertNum] = useState(1);
    const { navigate } = useNavigation()
    const isIOS = Platform.OS === 'ios';
    function renderForAndroid() {
        return (
            <View style={styles.checkboxContainer}>
                <CheckBox
                    value={value}
                    onValueChange={(val) => setValue(val)}
                    tintColors={{ true: Dodger_Blue, false: Dodger_Blue }}
                    checkboxSize={40}
                />
                <Text style={{ marginTop: normalizeY(4), fontFamily: poppins_Regular, fontSize: normalizeFont(14) }}>{`Accept Terms and Conditions`}</Text>
            </View>
        );
    }
    function avatarChange() {
        console.log('---------');
    }
    function openAlerts() {
        setCameraAllow(true)
    }
    async function alertState(num) {
        await setAlertNum(num + 1)
        console.log(alertNum);
        if (num == 3) {
            setCameraAllow(false)
            navigate('App')
        }
    }

    return (
        <View style={styles.container}>
            <Header onPress={() => navigate('Login')} />
            <ScrollView>
                <View style={styles.body}>
                    <Text style={styles.welcomeText}>Sign Up</Text>
                    <View style={styles.avatar}>
                        <Image source={avatar} style={{ height: width / 3 - 12, width: width / 3 - 12, borderRadius: width / 6 }} resizeMode="contain" />
                        <TouchableOpacity style={styles.plus} activeOpacity={0.7} onPress={() => avatarChange()}>
                            <AntDesign name="plus" color="white" size={15} />
                        </TouchableOpacity>
                    </View>
                    <CustomInput label="Name" value={username} onChangeText={(val) => setUsername(val)} />
                    <CustomInput label="Phone" value={phone} onChangeText={(val) => setPhone(val)} />
                    <CustomInput label="Email" value={email} onChangeText={(val) => setEmail(val)} />
                    <CustomInput label="Password" value={password} onChangeText={(val) => setPassword(val)} />
                    {renderForAndroid()}
                    <MainButton title="Sign Up" onPress={() => openAlerts()} />
                </View>
                <Modal
                    isVisible={cameraAllow}
                    backdropColor="#aaaa"
                    backdropOpacity={0.8}
                >
                    <View style={styles.avatarModalBody}>
                        {
                            alertNum == 1 ?
                                <TextComponent center>Would you Allow{'\n'}Your Camera</TextComponent>
                                : alertNum == 2 ?
                                    <TextComponent center>Would you Allow Your{'\n'}Music Apps</TextComponent>
                                    :
                                    <TextComponent center>Would you Allow Your{'\n'}Social Media</TextComponent>
                        }
                        <View style={styles.yesno}>
                            <TouchableOpacity style={styles.half} onPress={() => alertState(alertNum)} >
                                <TextComponent secondary PopMedium xmedium>Don't Allow</TextComponent>
                            </TouchableOpacity>
                            <TouchableOpacity style={{ ...styles.half, borderLeftWidth: 0.5 }} onPress={() => alertState(alertNum)} >
                                <TextComponent main PopMedium xmedium>Allow</TextComponent>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>
            </ScrollView>
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1,
        marginBottom: normalizeY(10),
        backgroundColor: '#fff',
    },
    welcomeText: {
        fontFamily: poppins_Bold,
        fontSize: normalizeFont(26, true),
        marginLeft: normalizeX(5)

    },
    avatar: {
        width: width / 3 + 12,
        height: width / 3 + 12,
        borderRadius: width / 6 + 6,
        borderWidth: 3,
        borderColor: Dodger_Blue,
        justifyContent: 'center',
        alignItems: "center",
        backgroundColor: 'white',
        alignSelf: 'center',
    },
    plus: {
        position: 'absolute',
        zIndex: 12,
        right: 0,
        bottom: 10,
        backgroundColor: Dodger_Blue,
        width: 30,
        height: 30,
        borderRadius: 15,
        justifyContent: 'center',
        alignItems: 'center',
    },
    inputContainer: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: "#E6E6E6",
        height: 80,
        marginLeft: normalizeX(5),
        marginTop: normalizeY(30),
        borderRadius: 6
    },
    titleStyle: {
        color: GREY_COLOR,
        marginLeft: normalizeX(20),
        marginTop: normalizeY(10)
    },
    inputStyle: {
        marginLeft: normalizeX(15),
        fontFamily: poppins_Medium,
        fontSize: normalizeFont(17)
    },
    checkboxContainer: {
        flexDirection: "row",
        marginVertical: normalizeY(15),
    },
    avatarModalBody: {
        width: '80%',
        flexDirection: 'column',
        backgroundColor: 'white',
        alignSelf: 'center',
        paddingTop: 20,
        borderRadius: 15,
    },
    yesno: {
        width: '100%',
        height: 50,
        flexDirection: 'row',
        borderTopColor: Line_Color,
        borderTopWidth: 0.5,
        marginTop: 20
    },
    half: {
        width: '50%',
        justifyContent: 'center',
        alignItems: 'center',
        borderLeftColor: Line_Color
    }
});
