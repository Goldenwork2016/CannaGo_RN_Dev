//import liraries
import React, { Component } from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { poppins_Medium, poppins_Regular, WHITE_COLOR, BLACK_COLOR, GREY_COLOR } from '../../utils/constants';
import Header from '../../common/Header'
import { Avatar } from 'react-native-paper'
import Ionicons from 'react-native-vector-icons/Ionicons';
import Text from '../../common/Text';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import BottomTab from '../../common/BottomTab';


export default Account = () => {
    return (
        <View style={styles.container}>
            <Header headerTitle="Account" />
            <View style={{ marginHorizontal: normalizeX(10), flex: 1 }}>
                <View style={{ flexDirection: "row" }}>
                    <Avatar.Image size={80} source={require("../../assets/images/profile.png")} style={{ margin: 20 }} />
                    <View style={{ marginTop: normalizeY(29) }}>
                        <Text style={styles.name}>Jeep Worker</Text>
                        <Text style={styles.email}>About</Text>
                    </View>
                </View>
                <View style={styles.inputContainer} >
                    <View style={{ marginTop: normalizeY(10), flexDirection: "row", flex: 1 }}>
                        <View style={{ flex: 0.99, paddingBottom: 0, marginBottom: 0 }}>
                            <Text style={styles.titleStyle}>Payment</Text>
                            <Text style={{ ...styles.email, marginLeft: normalizeX(9), fontSize: normalizeFont(13) }}>Visa**34</Text>
                        </View>
                        <Ionicons
                            color={GREY_COLOR}
                            name="ios-chevron-forward"
                            size={normalizeFont(25, true)}
                        />
                    </View>
                </View>
                <View style={styles.inputContainer} >
                    <View style={{ marginTop: normalizeY(10), flexDirection: "row", flex: 1 }}>
                        <View style={{ flex: 0.99, paddingBottom: 0, marginBottom: 0 }}>
                            <Text style={styles.titleStyle}>Address</Text>
                            <Text style={{ ...styles.email, marginLeft: normalizeX(9), fontSize: normalizeFont(13) }}>Address</Text>
                        </View>
                        <Ionicons
                            color={GREY_COLOR}
                            name="ios-chevron-forward"
                            size={normalizeFont(25, true)}
                        />
                    </View>
                </View>
                <View style={styles.inputContainer} >
                    <View style={{ marginTop: normalizeY(10), flexDirection: "row", flex: 1 }}>
                        <View style={{ flex: 0.99, paddingBottom: 0, marginBottom: 0 }}>
                            <Text style={styles.titleStyle}>Support</Text>
                            <Text style={{ ...styles.email, marginLeft: normalizeX(9), fontSize: normalizeFont(13) }}>Support</Text>
                        </View>
                        <Ionicons
                            color={GREY_COLOR}
                            name="ios-chevron-forward"
                            size={normalizeFont(25, true)}
                        />
                    </View>
                </View>
                <View style={styles.inputContainer} >
                    <View style={{ marginTop: normalizeY(10), flexDirection: "row", flex: 1 }}>
                        <View style={{ flex: 0.99, paddingBottom: 0, marginBottom: 0 }}>
                            <Text style={styles.titleStyle}>Promo Codes</Text>
                            <Text style={{ ...styles.email, marginLeft: normalizeX(9), fontSize: normalizeFont(13) }}>Promo Codes</Text>
                        </View>
                        <Ionicons
                            color={GREY_COLOR}
                            name="ios-chevron-forward"
                            size={normalizeFont(25, true)}
                        />
                    </View>
                </View>
            </View>
            <BottomTab />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: WHITE_COLOR,
    },
    name: {
        fontFamily: poppins_Medium,
        fontSize: normalizeFont(17)
    },
    email: {
        fontFamily: poppins_Regular,
        fontSize: normalizeFont(14),
        color: GREY_COLOR
    },
    inputContainer: {
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: "#E6E6E6",
        height: 80,
        marginLeft: normalizeX(5),

        borderRadius: 6,
        flexDirection: "row",
        paddingBottom: 0,
        marginBottom: 0
    },
    titleStyle: {
        color: BLACK_COLOR,
        marginLeft: normalizeX(10),
        fontFamily: poppins_Medium,
        fontSize: normalizeFont(17)
    },
});

