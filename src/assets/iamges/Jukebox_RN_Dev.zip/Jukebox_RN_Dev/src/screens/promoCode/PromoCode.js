
//import liraries
import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Text from '../../../src/common/Text'
import { poppins_Medium, poppins_Regular } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import Header from '../../common/Header'
import { useNavigation } from 'react-navigation-hooks'

const PromoCode = () => {
    const { navigate } = useNavigation()
    return (
        <View style={styles.container}>
            <Header headerTitle="PROMO CODES" onPress={() => navigate('Home')} />
            <View style={styles.body}>
                <View style={{ flex: 0.1 }}>
                    <Text style={styles.welcomeText}>{`Invite Your Friends`}</Text>
                </View>
                <Text style={styles.description}>{`Send this link to your friends and receive free deliveries:`}</Text>
                <TouchableOpacity onPress={() => console.log('email test')}>
                    <Text style={{ ...styles.welcomeText, textDecorationLine: 'underline' }}>{`www.1234567.14cgwe`}</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1
    },
    welcomeText: {
        fontFamily: poppins_Medium,
        fontSize: normalizeFont(13),
        marginTop: normalizeY(10),
        marginLeft: normalizeX(5),
    },
    description: {
        fontSize: normalizeFont(14),
        marginLeft: normalizeX(4),
        fontFamily: poppins_Regular
    }
})

export default PromoCode