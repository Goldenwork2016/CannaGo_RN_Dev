
//import liraries
import React from 'react';
import { View, StyleSheet } from 'react-native';
import Text from '../../../src/common/Text'
import { poppins_Medium, poppins_Regular } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import Header from '../../common/Header'
import MainButton from '../../components/MainButton';
import ConstantText from '../../constants/ConstantText';
import { useNavigation } from 'react-navigation-hooks'

const Support = () => {
    const { navigate } = useNavigation()
    return (
        <View style={styles.container}>
            <Header headerTitle="SUPPORT" onPress={() => navigate('Home')} />
            <View style={styles.body}>
                <View style={{ flex: 0.12 }}>
                    <Text style={styles.welcomeText}>{`Mesage About Support`}</Text>
                </View>
                <Text style={styles.description}>{ConstantText.support}</Text>
                <MainButton title="Contact us Email" onPress={() => navigate('PromoCode')} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        flex: 1
    },
    welcomeText: {
        fontFamily: poppins_Medium,
        fontSize: normalizeFont(15),
        marginTop: normalizeY(10),
        marginLeft: normalizeX(5)
    },
    description: {
        fontSize: normalizeFont(12),
        marginHorizontal: normalizeX(4),
        fontFamily: poppins_Regular,
        marginBottom: 30
    }
});

export default Support