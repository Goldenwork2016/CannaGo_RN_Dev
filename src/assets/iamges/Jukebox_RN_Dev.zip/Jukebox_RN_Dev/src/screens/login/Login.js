//import liraries
import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import Text from '../../../src/common/Text'
import { poppins_Bold } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import MainButton from '../../components/MainButton';
import TextComponent from '../../components/TextComponent';
import CustomInput from '../../components/CustomInput';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { useNavigation } from 'react-navigation-hooks'

export default Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { navigate } = useNavigation()
    useEffect(() => {
        let isMounted = true; // note this flag denote mount status
        if (isMounted) console.log('isMounted');
        return () => { isMounted = false }; // use effect cleanup to set flag false, if unmounted
    },[]);
    return (
        <SafeAreaView style={styles.container}>
            <KeyboardAwareScrollView>
                <View style={styles.body}>
                    <Text style={styles.welcomeText}>Welcome to {'\n'}Jukebox Carousel</Text>
                    <View style={{ marginVertical: 50 }}>
                        <CustomInput label="Email" value={email} onChangeText={(val) => setEmail(val)} />
                        <CustomInput label="Password" value={password} onChangeText={(val) => setPassword(val)} />
                        <TouchableOpacity style={{ alignItems: "flex-end" }} onPress={() => navigate('Forgot')}>
                            <TextComponent main PopMedium medium mt5>Forgot your password</TextComponent>
                        </TouchableOpacity>
                    </View>
                    <View style={{ marginBottom: 20 }}>
                        <MainButton title="Login" bgColor="white" onPress={() => navigate('App')} />
                        <MainButton title="Sign Up" onPress={() => navigate('Signup')} />
                        <TouchableOpacity>
                            <TextComponent main xmedium PopBold center>Login as Guest</TextComponent>
                        </TouchableOpacity>
                    </View>
                </View>
            </KeyboardAwareScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        marginTop: normalizeY(50),
        flex: 1
    },
    welcomeText: {
        fontFamily: poppins_Bold,
        fontSize: normalizeFont(30, true),
        marginVertical: normalizeY(10),
        marginLeft: normalizeX(5)
    },
});



