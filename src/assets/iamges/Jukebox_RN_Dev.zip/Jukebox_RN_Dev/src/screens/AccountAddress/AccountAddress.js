//import liraries
import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TextInput, TouchableOpacity, Image, Platform } from 'react-native';
import Text from '../../../src/common/Text'
import Header from '../../common/Header'
import { BLACK_COLOR, COLOR_WHITE, Dodger_Blue, GREY_COLOR, poppins_Bold, poppins_Medium, poppins_Regular, WHITE_COLOR } from '../../utils/constants';
import { normalizeFont, normalizeX, normalizeY } from '../../utils/Utils';
import { RadioButton } from 'react-native-paper';
import { useNavigation } from 'react-navigation-hooks'

const add = require('../../assets/images/add.png')
const edit = require('../../assets/images/edit.png')

export default AccountAddress = () => {
    const { navigate } = useNavigation()
    const [checked, setChecked] = React.useState(false);
    return (
        <View style={styles.container}>
            <Header headerTitle="ACCOUNT ADDRESS" onPress={() => navigate('Home')} />
            <View style={styles.body}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <TouchableOpacity onPress={() => navigate('Address')} activeOpacity={0.5} >
                        <Image source={add} resizeMode='contain' style={{ height: 22, width: 22, }} />
                    </TouchableOpacity>
                    <Text style={styles.addAnother}>Add another</Text>
                </View>
                <View style={{ height: 20, width: 40 }} />
                <Text style={{ ...styles.addAnother, marginLeft: 0 }}>Saved Address</Text>
                <View style={styles.checkArea}>
                    <View style={{ flexDirection: "row", width: '94%' }}>
                        <RadioButton
                            uncheckedColor={GREY_COLOR}
                            color={Dodger_Blue}
                            value={checked}
                            status={checked === false ? 'checked' : 'unchecked'}
                            onPress={(val) => setChecked(!checked)}
                        />
                        <Text style={{ marginTop: normalizeY(4), fontFamily: poppins_Regular, fontSize: normalizeFont(15), marginLeft: normalizeX(5) }}>Address 1212412 </Text>
                    </View>
                    <View>
                        <TouchableOpacity onPress={() => navigate('Address')}>
                            <Image source={edit} style={{ height: 17, width: 17 }} />
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </View >
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    body: {
        marginHorizontal: normalizeX(16),
        marginTop: normalizeY(30),
        flex: 1,
    },
    addAnother: {
        fontSize: normalizeFont(15),
        fontFamily: poppins_Medium,
        marginLeft: 10
    },
    checkArea: {
        flexDirection: "row",
        marginTop: normalizeY(2),
        alignItems: 'center',
    }
});