//import liraries
import React, { useEffect } from 'react';
import { SafeAreaView } from "react-native";
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from 'react-navigation-hooks'

function SplashScreen() {
  useEffect(() => {
    _bootstrapAsync();
  }, [])
  const { navigate } = useNavigation()

  async function _bootstrapAsync() {
    const userToken = await AsyncStorage.getItem('userToken');
    setTimeout(() => {
      navigate(userToken ? 'App' : 'Auth');
    }, 500);
  };

  return (
    <SafeAreaView style={{ flex: 1, width: '100%', height: '100%', backgroundColor: '#0091FF' }}></SafeAreaView>
  );
}

export default SplashScreen;