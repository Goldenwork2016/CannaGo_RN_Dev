//import liraries
import React, { useState } from 'react';
import { View, SafeAreaView, StyleSheet, FlatList } from 'react-native';
import Header from '../../common/Header'
import { Dodger_Blue } from '../../utils/constants';
import TextComponent from '../../components/TextComponent'
import SettingItem from '../../components/SettingItem'
import { useNavigation } from 'react-navigation-hooks'

// create a component
const Bluetooth = () => {
  const [settings, setSettings] = useState([
    { id: 1, title: 'Data Saver', status: 'Not Connected' },
    { id: 2, title: 'Playback', status: 'Not Connected' },
    { id: 3, title: 'Notifications', status: 'Not Connected' },
    { id: 4, title: 'Connect to Apps', status: 'Connected' },
  ])
  const { navigate } = useNavigation()
  const renderSettings = ({ item }) => (
    <SettingItem title={item.title} onPress={() => console.log(item.title)} status={item.status} />
  )
  return (
    <SafeAreaView style={styles.container}>
      <Header headerTitle={"BLUETOOTH"} onPress={() => navigate('Home')} />
      <View style={{marginHorizontal: 15}}>
        <FlatList
          data={settings}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderSettings}
        />
      </View>
    </SafeAreaView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
});

//make this component available to the app
export default Bluetooth;
