//import liraries
import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { FloatingLabelInput } from 'react-native-floating-label-input';

// create a component
const CustomInput = ({ ...props }) => {
  const [email, setEmail] = useState('');
  return (
    <View style={styles.container}>
      <FloatingLabelInput
        label={props.label}
        value={props.value}
        onChangeText={props.onChangeText}
        isPassword={(props.label == 'Password' || props.label == 'New Password' || props.label == 'Confirm Password') ? true : false}
        keyboardType={(props.label == 'Zip' || props.label == 'Phone' || props.label == 'Enter code') ? 'number-pad' : 'default'}
        containerStyles={{
          borderWidth: 1,
          paddingHorizontal: 10,
          backgroundColor: '#fff',
          borderColor: '#E5E5E5',
          borderRadius: 6,
          height: 68,
        }}
        customLabelStyles={{
          fontSizeFocused: 12,
        }}
        labelStyles={{
          backgroundColor: '#fff',
          paddingHorizontal: 5,
          fontFamily: 'Poppins-Regular',
        }}
        inputStyles={{
          color: '#000',
          paddingHorizontal: 10,
          fontFamily: 'Poppins-Regular',
          fontSize: 17
        }}
      />
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    paddingVertical: 5
  },
});

//make this component available to the app
export default CustomInput;
