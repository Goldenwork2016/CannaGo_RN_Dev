import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';

const Shoot = ({...props}) => {
  return (
    <View style={styles.outer}>
      <TouchableOpacity style={styles.inner} activeOpacity={0.5} onPress={props.onPress}>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  outer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 6,
    borderColor: '#ff6464aa',
    alignItems: 'center',
    justifyContent: 'center'
  },
  inner: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#FF6464'
  }
});

export default Shoot;
