import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const MenuIcon = ({ ...props }) => (
  <TouchableOpacity style={styles.menu} activeOpacity={0.5} onPress={props.onPress}>
    <MaterialCommunityIcons name="menu" color="black" size={28} />
  </TouchableOpacity>
)

const styles = StyleSheet.create({
  menu: {
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 25,
    marginBottom: 10,
    marginLeft: 20
  }
})
export default MenuIcon