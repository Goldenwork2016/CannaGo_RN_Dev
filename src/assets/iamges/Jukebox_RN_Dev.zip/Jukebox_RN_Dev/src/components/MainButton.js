import React from 'react';
import { TouchableOpacity, Dimensions, StyleSheet } from 'react-native';
import TextComponent from './TextComponent'
import Colors from '../constants/Colors'

const MainButton = ({ ...props }) => (
  <TouchableOpacity
    style={[styles.main,
    {
      width: props.width ? props.width : '100%',
      height: props.height ? props.height : 56,
      backgroundColor: props.bgColor ? props.bgColor : Colors.bottomBar,
    }]}
    onPress={props.onPress}
    activeOpacity={0.7}
    disabled={props.disabled}
  >
    {
      props.bgColor ?
        <TextComponent main xmedium PopBold>{props.title}</TextComponent>
        :
        <TextComponent white xmedium PopBold>{props.title}</TextComponent>
    }
  </TouchableOpacity>
)

const styles = StyleSheet.create({
  main: {
    justifyContent: 'center',
    alignItems: "center",
    borderRadius: 28,
    paddingHorizontal: 20,
    borderWidth: 2,
    borderColor: Colors.bottomBar,
    zIndex: 10,
    marginVertical: 8
  },
})
export default MainButton