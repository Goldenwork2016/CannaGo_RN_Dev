import React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import TextComponent from './TextComponent'

const SettingItem = ({ ...props }) => (
  <TouchableOpacity
    style={{ ...styles.container, paddingVertical: props.src ? 0 : 12 }}
    onPress={props.onPress}
  >
    <View style={styles.item}>
      {props.src && <Image source={props.src} style={styles.icon} resizeMode="contain" />}
      <TextComponent xmedium PopMedium>{props.title}</TextComponent>
    </View>
    {
      props.status ?
        props.status == "Connected" ?
          <TextComponent xmedium PopMedium>{props.status}</TextComponent>
          :
          <TextComponent xmedium PopMedium lightgrey>{props.status}</TextComponent>
        :
        <MaterialCommunityIcons name="chevron-right" size={30} color="#b5b5b5" />
    }
  </TouchableOpacity>
)

const styles = StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
    borderBottomColor: '#E5E5E5',
    borderBottomWidth: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  icon: {
    width: 23,
    height: 23,
    marginVertical: 15,
    marginRight: 15
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
  }
})
export default SettingItem