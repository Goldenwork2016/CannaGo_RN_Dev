import React from 'react';
import styled from 'styled-components/native';

function TextComponent({ ...props }) {
    return <Text {...props} onPress={props.onPress}>{props.children}</Text>
}

const Text = styled.Text`
    color: ${props => props.color ?? "#000"}

    ${({ xtitle, title, stitle, large, xlarge, medium, xmedium, small, msmall, mini }) => {
        switch (true) {
            case xtitle:
                return 'font-size: 52px;'
            case title:
                return 'font-size: 48px;'
            case stitle:
                return 'font-size: 36px;'
            case xlarge:
                return 'font-size: 28px;'
            case large:
                return 'font-size: 22px;'
            case xmedium:
                return 'font-size: 18px;'
            case medium:
                return 'font-size: 16px;'
            case small:
                return 'font-size: 12px;'
            case msmall:
                return 'font-size: 10px;'
            case mini:
                return 'font-size: 8px;'
            default:
                return 'font-size: 14px;'
        }
    }};

    ${({ light, bold, heavy }) => {
        switch (true) {
            case light:
                return 'font-weight: 200'
            case bold:
                return 'font-weight: 600'
            case heavy:
                return 'font-weight: 700'
            default:
                return 'font-weight: 400'
        }
    }}

    ${({ L3, L5, L0, H25, H4 }) => {
        switch (true) {
            case L3:
                return 'letter-spacing: 3px'
            case L5:
                return 'letter-spacing: 5px'
            case L0:
                return 'letter-spacing: 10px'
            case H25:
                return 'line-height: 25px'
            default:
                return 'letter-spacing: 0px'
        }
    }}
    
    ${({ mt3, mt5, mt10, mt15, mt20, pt5, pt20, mb5, mb20, pb5, pb20 }) => {
        switch (true) {
            case mt3:
                return 'margin-top: 3px'
            case mt5:
                return 'margin-top: 5px'
            case mt10:
                return 'margin-top: 10px'
            case mt15:
                return 'margin-top: 15px'
            case mt20:
                return 'margin-top: 20px'
            case pt5:
                return 'padding-top: 5px'
            case pt20:
                return 'padding-top: 20px'
            case mb5:
                return 'margin-bottom: 5px'
            case mb20:
                return 'margin-bottom: 20px'
            case pb5:
                return 'padding-bottom: 5px'
            case pb20:
                return 'padding-bottom: 20px'
            default:
                return 'margin-top: 0'
        }
    }}

    ${({ center, right }) => {
        switch (true) {
            case center:
                return 'text-align: center'
            case right:
                return 'text-align: right'
            default:
                return 'text-align: left'
        }
    }}

    ${({ PopBold, PopMedium, PopRegular }) => {
        switch (true) {
            case PopBold:
                return 'fontFamily: Poppins-Bold'
            case PopMedium:
                return 'fontFamily: Poppins-Medium'
            case PopRegular:
                return 'fontFamily: Poppins-Regular'
            default:
                return 'fontFamily: Poppins-Regular'
        }
    }}

    ${({ main, secondary, text, name, grey, subTxt, lightgrey, more, disabled, white, green }) => {
        switch (true) {
            case main:
                return 'color: #0091FF'
            case secondary:
                return 'color: #FF3434'
            case text:
                return 'color: #092C4C'
            case name:
                return 'color: #1B3C87'
            case grey:
                return 'color: grey'
            case subTxt:
                return 'color: #606060'
            case lightgrey:
                return 'color: #ACACAC'
            case more:
                return 'color: #F13424'
            case disabled:
                return 'color: #49485C'
            case white:
                return 'color: #FFFFFF'
            case green:
                return 'color: #127127'
            default:
                return 'color: black'
        }
    }}
`

export default TextComponent;