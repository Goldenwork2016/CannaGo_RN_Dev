//This is an example code for Bottom Navigation//
import 'react-native-gesture-handler';
import React from 'react';
import { Image } from 'react-native';
//import React Navigation
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createStackNavigator } from 'react-navigation-stack';

import HomeScreen from '../screens/home/Home';
import ProfileScreen from '../screens/profile/profile';
import AccountAddressScreen from '../screens/AccountAddress/AccountAddress';
import AddressScreen from '../screens/address/Address';
import SupportScreen from '../screens/support/Support';
import PromoCodeScreen from '../screens/promoCode/PromoCode';
import SettingsScreen from '../screens/settings/Settings';
import BluetoothScreen from '../screens/bluetooth/Bluetooth.js';
import CameraScreen from '../screens/camera/camera';
import BitmojiScreen from '../screens/bitmoji/Bitmoji';
import MusicScreen from '../screens/music/music';
import SocialScreen from '../screens/social/social';
import SplashScreen from '../screens/splash/SplashScreen';
import LoginScreen from '../screens/login/Login';
import SignupScreen from '../screens/signup/SignUp';
import ForgotScreen from '../screens/forgotPassword/ForgotPassword';
import ConfirmScreen from '../screens/confirmCode/ConfirmCode';
import ChangeScreen from '../screens/changePassword/ChangePassword';

import Colors from '../constants/Colors';

const profile = require('../assets/images/Profile.png')
const camera = require('../assets/images/Camera.png')
const music = require('../assets/images/Music.png')
const social = require('../assets/images/Social.png')
const profile_active = require('../assets/images/Profile1.png')
const camera_active = require('../assets/images/Camera1.png')
const music_active = require('../assets/images/Music1.png')
const social_active = require('../assets/images/Social1.png')

const ProfileStack = createStackNavigator(
  {
    Home: {
      screen: HomeScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Profile: {
      screen: ProfileScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    AccountAddress: {
      screen: AccountAddressScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Address: {
      screen: AddressScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Support: {
      screen: SupportScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    PromoCode: {
      screen: PromoCodeScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Settings: {
      screen: SettingsScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Bluetooth: {
      screen: BluetoothScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
  },
);

ProfileStack.navigationOptions = ({ navigation }) => {
  let tabBarVisible;
  if (navigation.state.routes.length > 1) {
    navigation.state.routes.map(route => {
      if (route.routeName === "Profile" ||
        route.routeName === "AccountAddress" ||
        route.routeName === "Address" ||
        route.routeName === "Support" ||
        route.routeName === "PromoCode") {
        tabBarVisible = false;
      } else {
        tabBarVisible = true;
      }
    });
  }
  return {
    tabBarVisible
  };
}

const CameraStack = createStackNavigator(
  {
    Camera: {
      screen: CameraScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Bitmoji: {
      screen: BitmojiScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
  },
);

CameraStack.navigationOptions = ({ navigation }) => {
  let tabBarVisible = false;
  return {
    tabBarVisible
  };
}

const MusicStack = createStackNavigator(
  {
    Music: {
      screen: MusicScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Settings: {
      screen: SettingsScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Bluetooth: {
      screen: BluetoothScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
  },
);

const SocialStack = createStackNavigator(
  {
    Social: {
      screen: SocialScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Settings: {
      screen: SettingsScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Bluetooth: {
      screen: BluetoothScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
  },
);

const AppStack = createBottomTabNavigator(
  {
    Profile: { screen: ProfileStack },
    Camera: { screen: CameraStack },
    Music: { screen: MusicStack },
    Social: { screen: SocialStack },
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, tintColor }) => {
        const { routeName } = navigation.state;
        let iconUrl
        if (routeName === 'Profile') {
          iconUrl = focused ? profile : profile_active;
        } else if (routeName === 'Camera') {
          iconUrl = focused ? camera : camera_active;
        } else if (routeName === 'Music') {
          iconUrl = focused ? music : music_active;
        } else if (routeName === 'Social') {
          iconUrl = focused ? social : social_active;
        }
        return <Image source={iconUrl} style={{ width: 26, height: 26 }} resizeMode="contain" />
      },
    }),
    tabBarOptions: {
      activeTintColor: Colors.white,
      inactiveTintColor: 'gray',
      style: {
        borderTopColor: 'transparent',
        backgroundColor: Colors.bottomBar,
      },
      showLabel: false,
    },
  }
);
const AuthStack = createStackNavigator(
  {
    Login: {
      screen: LoginScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Signup: {
      screen: SignupScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Forgot: {
      screen: ForgotScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Confirm: {
      screen: ConfirmScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
    Change: {
      screen: ChangeScreen,
      navigationOptions: {
        headerShown: false,
      },
    },
  }
)
const App = createSwitchNavigator(
  {
    Splash: SplashScreen,
    Auth: AuthStack,
    App: AppStack
  }
)
export default createAppContainer(App);